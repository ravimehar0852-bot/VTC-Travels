/* VTC Travels — shared script. EDIT BUSINESS DETAILS, PACKAGES & DESTINATIONS BELOW. */
const BIZ={name:"VTC Travels",wa:"919354930535",phones:["+91 93549 30535","+91 93552 30535"],email:"travelsvtc@gmail.com",
address:"C-35, Budh Vihar Phase-1, New Delhi, Delhi 110086",insta:"https://www.instagram.com/travelsvtc/",
facebook:""/* add official Facebook page URL after verification */};

/* PACKAGES — price:null shows "Request Price". Add a number (e.g. 4999) only when verified.
   Durations are indicative; confirm with the owner. Photos: assets/images/<destination-slug>.jpg */
const PACKAGES=[
{id:"jaipur-weekend",title:"Delhi to Jaipur Weekend Getaway",dests:["Jaipur"],duration:"2 Nights / 3 Days",days:3,types:["weekend","family","group"],desc:"A relaxed weekend among forts, palaces and bazaars of the Pink City.",highlights:["Amber Fort","City Palace","Local bazaars"],price:null},
{id:"rishikesh-haridwar",title:"Delhi to Rishikesh & Haridwar",dests:["Rishikesh","Haridwar"],duration:"2 Nights / 3 Days",days:3,types:["pilgrimage","adventure","group","weekend"],desc:"Ganga aarti, riverside calm and spiritual experiences in two sacred towns.",highlights:["Ganga Aarti","Laxman Jhula","Har Ki Pauri"],price:null},
{id:"vaishno-amritsar",title:"Vaishno Devi & Amritsar Pilgrimage",dests:["Vaishno Devi","Amritsar"],duration:"4 Nights / 5 Days",days:5,types:["pilgrimage","family","group"],desc:"A devotional journey combining Mata Vaishno Devi darshan with the Golden Temple.",highlights:["Vaishno Devi Darshan","Golden Temple","Wagah Border"],price:null},
{id:"udaipur-abu",title:"Udaipur & Mount Abu Escape",dests:["Udaipur","Mount Abu"],duration:"3 Nights / 4 Days",days:4,types:["family","honeymoon","group"],desc:"Lakes, palaces and Rajasthan's only hill station in one scenic trip.",highlights:["Lake Pichola","City Palace","Nakki Lake"],price:null},
{id:"corbett",title:"Jim Corbett Nature Getaway",dests:["Jim Corbett"],duration:"2 Nights / 3 Days",days:3,types:["adventure","family","weekend"],desc:"Forest landscapes and wildlife experiences close to Delhi.",highlights:["Jungle safari*","Riverside views","Nature walks"],price:null},
{id:"mussoorie-chakrata",title:"Mussoorie & Chakrata Adventure",dests:["Mussoorie","Chakrata"],duration:"3 Nights / 4 Days",days:4,types:["adventure","honeymoon","family","group"],desc:"Misty hills in Mussoorie and quiet Himalayan viewpoints in Chakrata.",highlights:["Mall Road","Tiger Falls","Mountain views"],price:null}];

const DESTINATIONS=[
{n:"Jaipur",g:["north","heritage"],intro:"Rajasthan's Pink City, known for forts, palaces and markets.",exp:["Amber Fort","City Palace","Hawa Mahal"]},
{n:"Mussoorie",g:["north"],intro:"A classic hill station in Uttarakhand with cool air and valley views.",exp:["Mall Road","Kempty Falls","Gun Hill"]},
{n:"Chakrata",g:["north"],intro:"A quieter Himalayan getaway with forests and viewpoints.",exp:["Tiger Falls","Deoban","Scenic drives"]},
{n:"Rishikesh",g:["north"],intro:"Riverside town by the Ganga, loved for yoga and adventure.",exp:["Laxman Jhula","Ganga Aarti","River rafting*"]},
{n:"Haridwar",g:["north","pilgrimage"],intro:"One of North India's holiest cities on the banks of the Ganga.",exp:["Har Ki Pauri","Evening Aarti","Mansa Devi"]},
{n:"Jim Corbett",g:["north"],intro:"India's oldest national park, set among forests and rivers.",exp:["Jungle safari*","Nature stay","Bird watching"]},
{n:"Udaipur",g:["heritage"],intro:"The City of Lakes, with royal palaces and old-town charm.",exp:["Lake Pichola","City Palace","Sajjangarh"]},
{n:"Mount Abu",g:["heritage"],intro:"Rajasthan's hill station, known for lakes and Dilwara temples.",exp:["Nakki Lake","Dilwara Temples","Sunset Point"]},
{n:"Amritsar",g:["heritage","pilgrimage"],intro:"Home of the Golden Temple and rich Punjabi culture.",exp:["Golden Temple","Jallianwala Bagh","Wagah Border"]},
{n:"Vaishno Devi",g:["pilgrimage"],intro:"A major pilgrimage site in the Trikuta hills of Jammu & Kashmir.",exp:["Mata darshan","Katra base","Bhairon Temple"]}];
const TYPES={family:"Family Holidays",group:"Group Tours",honeymoon:"Honeymoon Trips",pilgrimage:"Pilgrimage Tours",weekend:"Weekend Getaways",adventure:"Adventure & Nature"};

/* ---------- helpers ---------- */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const slug=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,"-");
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* Reusable WhatsApp opener: fields = {label: value}; empty values are skipped */
function openWhatsApp(fields={}){
  const lines=["Hello VTC Travels, I would like to enquire about a trip.",""];
  Object.entries(fields).forEach(([k,v])=>{if(v)lines.push(k+": "+v)});
  const url="https://wa.me/"+BIZ.wa+"?text="+encodeURIComponent(lines.join("\n"));
  const w=window.open(url,"_blank");
  if(!w)window.location.href=url; // popup blocked: open in same tab
  return url;
}
/* Photo with graceful fallback: if the file is missing, the navy gradient + name remains */
const photo=n=>`<div class="ph"><img src="assets/images/${slug(n)}.jpg" alt="${esc(n)} travel photograph" loading="lazy" onerror="this.remove()"><span>${esc(n)}</span></div>`;

/* ---------- header / footer ---------- */
const LINKS=[["index.html","Home"],["packages.html","Packages"],["destinations.html","Destinations"],["about.html","About Us"],["contact.html","Contact"]];
function buildChrome(){
  const cur=location.pathname.split("/").pop()||"index.html";
  const h=$("#site-header");
  if(h)h.outerHTML=`<header class="nav"><div class="wrap"><a class="logo" href="index.html">VTC <span>Travels</span></a>
  <button class="burger" aria-label="Open menu" aria-expanded="false">☰</button>
  <nav class="links" aria-label="Main">${LINKS.map(([u,t])=>`<a href="${u}" ${u===cur?'class="active" aria-current="page"':""}>${t}</a>`).join("")}
  <button class="btn gold sm" data-wa>WhatsApp Booking</button></nav></div></header>`;
  const f=$("#site-footer");
  if(f)f.outerHTML=`<footer><div class="wrap"><div class="cols">
  <div><h3>VTC Travels</h3><p>Travel More. Worry Less. Create Memories.</p><p>${BIZ.address}</p></div>
  <div><h3>Explore</h3>${LINKS.map(([u,t])=>`<a href="${u}">${t}</a>`).join("")}</div>
  <div><h3>Contact</h3>${BIZ.phones.map(p=>`<a href="tel:${p.replace(/\s/g,"")}">${p}</a>`).join("")}<a href="mailto:${BIZ.email}">${BIZ.email}</a><a href="${BIZ.insta}" target="_blank" rel="noopener">Instagram @travelsvtc</a>${BIZ.facebook?`<a href="${BIZ.facebook}" target="_blank" rel="noopener">Facebook</a>`:""}</div>
  </div><p class="copy">© <span id="yr"></span> VTC Travels. Inquiries do not confirm a booking; availability and prices are shared by our team.</p></div></footer>
  <a class="wa-float" href="#" data-wa aria-label="Chat on WhatsApp">💬</a>
  <dialog id="dlg"></dialog>`;
  const y=$("#yr");if(y)y.textContent=new Date().getFullYear();
  const b=$(".burger"),l=$(".links");
  b.addEventListener("click",()=>{const o=l.classList.toggle("open");b.setAttribute("aria-expanded",o);b.textContent=o?"✕":"☰"});
}

/* ---------- renderers ---------- */
const priceText=p=>p.price?"From ₹"+Number(p.price).toLocaleString("en-IN")+" per person":"Request Price";
const pkgCard=p=>`<article class="card">${photo(p.dests[0])}<div class="cb"><span class="tag">${p.duration}</span><h3>${p.title}</h3><p>${p.desc}</p><p class="price">${priceText(p)}</p>
<div class="row"><button class="btn sm" data-detail="${p.id}">View Details</button><button class="btn sm gold" data-wa data-pkg="${esc(p.title)}">WhatsApp Inquiry</button></div></div></article>`;
const destCard=d=>{const rel=PACKAGES.filter(p=>p.dests.includes(d.n));
  return `<article class="card" id="${slug(d.n)}">${photo(d.n)}<div class="cb"><h3>${d.n}</h3><p>${d.intro}</p><p><strong>Best experiences:</strong> ${d.exp.join(", ")}</p>
  ${rel.length?`<p><strong>Related:</strong> ${rel.map(p=>`<a href="packages.html?q=${encodeURIComponent(d.n)}" style="text-decoration:underline">${p.title}</a>`).join("; ")}</p>`:""}
  <div class="row"><button class="btn sm gold" data-wa data-dest="${d.n}">Plan a Trip</button></div></div></article>`};
const showCard=d=>`<a class="card" href="destinations.html#${slug(d.n)}" aria-label="${d.n}">${photo(d.n)}</a>`;

function renderPackages(){
  const box=$("#pkg-grid");if(!box)return;
  const limit=+box.dataset.limit||99;
  if(!$("#f-q")){box.innerHTML=PACKAGES.slice(0,limit).map(pkgCard).join("");return}
  const dsel=$("#f-dest"),tsel=$("#f-type");
  [...new Set(PACKAGES.flatMap(p=>p.dests))].forEach(d=>dsel.add(new Option(d,d)));
  Object.entries(TYPES).forEach(([k,v])=>tsel.add(new Option(v,k)));
  const q0=new URLSearchParams(location.search).get("q");if(q0)$("#f-q").value=q0;
  const run=()=>{const q=$("#f-q").value.toLowerCase().trim(),d=dsel.value,t=tsel.value,du=$("#f-dur").value;
    const out=PACKAGES.filter(p=>(!q||(p.title+p.desc+p.dests.join(" ")+p.highlights.join(" ")).toLowerCase().includes(q))&&(!d||p.dests.includes(d))&&(!t||p.types.includes(t))&&
      (!du||(du==="short"&&p.days<=3)||(du==="mid"&&p.days===4)||(du==="long"&&p.days>=5)));
    box.innerHTML=out.length?out.map(pkgCard).join(""):'<p class="empty">No packages match. Clear the filters or <a href="contact.html" style="text-decoration:underline">request a customized trip</a>.</p>';
    $("#f-count").textContent=out.length+" package"+(out.length===1?"":"s")+" found"};
  $$("#f-q,#f-dest,#f-type,#f-dur").forEach(e=>e.addEventListener("input",run));run();
}
function renderDestinations(){
  $$("[data-group]").forEach(b=>b.innerHTML=DESTINATIONS.filter(d=>d.g.includes(b.dataset.group)).map(destCard).join(""));
  const s=$("#dest-show");if(s)s.innerHTML=DESTINATIONS.map(showCard).join("");
}
function showDetail(id){
  const p=PACKAGES.find(x=>x.id===id),dlg=$("#dlg");if(!p)return;
  const ph="[Editable: details shared on request]";
  dlg.innerHTML=`<div class="dlg"><button class="close" aria-label="Close" onclick="this.closest('dialog').close()">✕</button><h3>${p.title}</h3><p class="tag" style="margin-top:.5rem">${p.duration}</p>
  <h4>Overview</h4><p>${p.desc}</p><ul>${p.highlights.map(h=>`<li>${h}</li>`).join("")}</ul>
  <h4>Day-wise itinerary</h4><ul>${Array.from({length:p.days},(_,i)=>`<li>Day ${i+1}: ${ph}</li>`).join("")}</ul>
  <h4>Transportation</h4><p>${ph}</p><h4>Hotel / stay</h4><p>${ph}</p><h4>Meals</h4><p>${ph}</p><h4>Exclusions</h4><p>${ph}</p>
  <h4>Important travel information</h4><p>Prices, dates, inclusions and availability are confirmed by our team before booking. *Activities depend on season and local rules.</p>
  <p class="price" style="margin:1rem 0">${priceText(p)}</p><button class="btn gold" data-wa data-pkg="${esc(p.title)}">Send Booking Inquiry on WhatsApp</button></div>`;
  dlg.showModal();
}

/* ---------- forms ---------- */
function setupForms(){
  const quick=$("#quick-form");
  if(quick){const sel=$("[name=dest]",quick);DESTINATIONS.forEach(d=>sel.add(new Option(d.n,d.n)));
    quick.addEventListener("submit",e=>{e.preventDefault();const f=Object.fromEntries(new FormData(quick));
      openWhatsApp({"Destination":f.dest,"Travel date":f.date,"Travellers":f.pax})});}
  const form=$("#trip-form");
  if(form){const sel=$("[name=dest]",form);DESTINATIONS.forEach(d=>sel.add(new Option(d.n,d.n)));sel.add(new Option("Other / Not sure","Other / Not sure"));
    const pre=new URLSearchParams(location.search).get("dest");if(pre)sel.value=pre;
    form.addEventListener("submit",e=>{e.preventDefault();
      const f=Object.fromEntries(new FormData(form));const errs={};
      if(!f.name.trim())errs.name="Please enter your full name.";
      if(!/^[+\d][\d\s-]{8,14}$/.test(f.phone.trim()))errs.phone="Enter a valid phone number (at least 10 digits).";
      if(f.email&&!/^\S+@\S+\.\S+$/.test(f.email))errs.email="Enter a valid email address or leave it blank.";
      if(!f.dest)errs.dest="Please choose a destination.";
      if(f.date&&f.ret&&f.ret<f.date)errs.ret="Return date must be after the travel date.";
      $$("[data-err]",form).forEach(s=>{const k=s.dataset.err;s.textContent=errs[k]||"";const i=$(`[name=${k}]`,form);i&&i.classList.toggle("invalid",!!errs[k])});
      const st=$("#form-status");
      if(Object.keys(errs).length){st.textContent="Please fix the highlighted fields and try again.";$(".invalid",form).focus();return}
      openWhatsApp({"Name":f.name,"Phone":f.phone,"Email":f.email,"Destination":f.dest,"Departing from":f.city,"Travel date":f.date,"Return date":f.ret,
        "Adults":f.adults,"Children":f.children,"Budget":f.budget,"Trip type":f.type,"Additional requirements":f.notes});
      st.innerHTML='WhatsApp should open with your details. If it did not, <a href="https://wa.me/'+BIZ.wa+'" style="text-decoration:underline">tap here to open WhatsApp</a> or call '+BIZ.phones[0]+'. This is an inquiry only; it does not confirm a booking.';
    });}
}

/* ---------- global click handling ---------- */
document.addEventListener("click",e=>{
  const w=e.target.closest("[data-wa]");
  if(w){e.preventDefault();const d=w.dataset;openWhatsApp({"Package":d.pkg,"Destination":d.dest});const dl=$("#dlg");if(dl&&dl.open)dl.close();return}
  const m=e.target.closest("[data-detail]");if(m)showDetail(m.dataset.detail);
  if(e.target.id==="dlg")e.target.close();
});
document.addEventListener("DOMContentLoaded",()=>{buildChrome();renderPackages();renderDestinations();setupForms()});
